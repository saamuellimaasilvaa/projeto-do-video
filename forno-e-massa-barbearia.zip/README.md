# Forno e Massa - Barbearia Premium

Site Landing Page responsivo, moderno e de altíssimo nível visual desenvolvido para a **Forno e Massa Barbearia Premium**.

## 🚀 Tecnologias Utilizadas
- **HTML5 & CSS3**
- **Tailwind CSS** (design responsivo e estilização premium)
- **React 18** (desenvolvimento de componentes e estado)
- **Framer Motion** (animações fluidas e scroll reveal)
- **Google Fonts**: *Playfair Display* & *Raleway*

---

## 🛠️ Como Hospedar na Netlify

1. Faça login na sua conta da [Netlify](https://www.netlify.com/).
2. Vá em **"Sites"** e depois no botão **"Add new site"** -> **"Deploy manually"**.
3. Arraste a pasta descompactada ou este arquivo `.zip` diretamente para a área de upload do Netlify.
4. Seu site estará publicado e online em questão de segundos!

---

## 💜 Como Importar no Lovable.dev

1. Acesse o [Lovable.dev](https://lovable.dev/).
2. Crie um novo projeto ou selecione importar código/HTML.
3. Utilize os arquivos contidos neste ZIP (`index.html`) para inicializar seu projeto.

---

## 📌 Informações do Negócio
- **Nome**: Forno e Massa
- **Endereço**: Rua Maquino 225
- **Telefone**: (16) 51651-6541
- **Cores**: Dourado Premium (`#D4AF37`) & Azul Escuro/Midnight (`#1A1A2E`)
